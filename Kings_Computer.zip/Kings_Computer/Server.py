#!/usr/bin/python3   

import socket
import os
from _thread import *
import mysql.connector
import datetime
from ast import literal_eval


Date = datetime.date.today()
Time = datetime.datetime.now().time()


mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="password",
  database="Kings_Computer",
  auth_plugin='mysql_native_password'
)

mycursor = mydb.cursor()


ServerSocket = socket.socket()
host = '192.168.0.105'
port = 1286
ThreadCount = 0
try:
    ServerSocket.bind((host, port))
except socket.error as e:
    print(str(e))

ServerSocket.listen(5)


def threaded_client(connection):
    
    while True:
        data = connection.recv(2048)

        #Data_Final = dict(e.split(':') for e in str(data.decode('utf-8')).split(','))
        Data_Final = data.decode('utf-8')
        print(str(data.decode('utf-8')))

        print(Data_Final[1])


        if str(Data_Final[2]) == "Login":

            mycursor.execute("SELECT * FROM Devices WHERE Email = '"+str(Data_Final["Email"])+"' AND Password = '"+str(Data_Final["Password"])+"'")

            myresult = mycursor.fetchone()

            print("found")

            if myresult:
                Date_Time = str(Date.strftime("%d-%m-%Y"))+" "+str(Time.strftime("%I:%M %P"))

                Make_Logs = "INSERT INTO Login (Email, Password, Purpose, Date_Time) VALUES (%s, %s, %s, %s)"
                Values = (str(Data_Final["Email"]), str(Data_Final["Password"]), "Login", str(Date_Time))
                mycursor.execute(Make_Logs, Values)

                mydb.commit()

                mycursor.execute("SELECT Full_Name FROM Signup WHERE Email = '"+str(Data_Final["Email"])+"' AND Password = '"+str(Data_Final["Password"])+"'")

                GetName = mycursor.fetchone()

                for Name in GetName:
                    UpdateDevice = "UPDATE Devices SET Running = 'True' WHERE Email = '"+str(Data_Final["Email"])+"'"
                    mycursor.execute(UpdateDevice)
                    mydb.commit()

                    connection.sendall(("Type : Found"+",Name : "+str(Name)).encode())

            else:
                connection.sendall(("Type : Not_Found"+",Name : None").encode())



        if str(Data_Final[1]) == "Connect":
            
            mycursor.execute("SELECT IP FROM Devices WHERE Email = '"+str(Data_Final["Email"])+"'")

            myresult = mycursor.fetchone()
            
            if myresult:
                connection.sendall(("Purpose : Connect"+",IP : "+str(myresult[0])).encode())

            else:
                connection.sendall(("Purpose : Connect"+",IP : None").encode())
                
            

        if str(Data_Final[4]) == "Signup":

            mycursor.execute("SELECT * FROM Signup WHERE Email = '"+str(Data_Final["Email"])+"' AND Email = '"+str(Data_Final["Email"])+"'")

            myresult = mycursor.fetchone()

            if myresult:
                connection.sendall(("Type : Found,Purpose : Signup").encode())
            else:
                Date_Time = str(Date.strftime("%d-%m-%Y"))+" "+str(Time.strftime("%I:%M %P"))

                Make_Logs = "INSERT INTO Signup (Full_Name, Email, Number, Password, Date_Time) VALUES (%s, %s, %s, %s, %s)"
                Values = (str(Data_Final["FullName"]), str(Data_Final["Email"]), str(Data_Final["Number"]), str(Data_Final["Password"]), str(Date_Time))
                mycursor.execute(Make_Logs, Values)

                connection.sendall(("Type : Accounted_Created,Purpose : Signup").encode())


        if str(Data_Final[2]) == "Logout":
            Date_Time = str(Date.strftime("%d-%m-%Y"))+" "+str(Time.strftime("%I:%M %P"))

            UpdateDevice = "UPDATE Devices SET Running = 'False' WHERE Email = '"+str(Data_Final["Email"])+"'"
            mycursor.execute(UpdateDevice)
            mydb.commit()


            Make_Logs = "INSERT INTO Login (Email, Password, Purpose, Date_Time) VALUES (%s, %s, %s, %s)"
            Values = (str(Data_Final["Email"]), str(Data_Final["Password"]), "Logout", str(Date_Time))
            mycursor.execute(Make_Logs, Values)


        if str(Data_Final[3]) == "ContactUS":

            Date_Time = str(Date.strftime("%d-%m-%Y"))+" "+str(Time.strftime("%I:%M %P"))

            Contact_US = "INSERT INTO ContactUS (Name, Email, Message, Date_Time) VALUES (%s, %s, %s, %s)"
            Contact_US_Value = (str(Data_Final["Name"]), str(Data_Final["Email"]), str(Data_Final["Message"]), str(Date_Time))

            mycursor.execute(Contact_US, Contact_US_Value)
            mydb.commit()
            connection.sendall(("Status : Done,Purpose : ContactUS").encode())
            

        if str(Data_Final[1]) == "Profile":
            Date_Time = str(Date.strftime("%d-%m-%Y"))+" "+str(Time.strftime("%I:%M %P"))

            mycursor.execute("SELECT Full_Name, Email, Mobile_Number, OS_Type, OS_Name, Ram_Size, Storage_Size ,Cores, Created_Date, Expiry_Date, Password FROM Devices WHERE Email = '"+str(Data_Final["Email"])+"' AND Email = '"+str(Data_Final["Email"])+"'")

            myresult = mycursor.fetchall()

            for Name in myresult:
                connection.sendall(("Full_Name : "+Name[0]+",Email : "+Name[1]+",Mobile_Number : "+Name[2]+",OS_Type : "+Name[3]+",OS_Name : "+Name[4]+",Ram_Size : "+Name[5]+",Storage_Size : "+Name[6]+",Cores : "+Name[7]+",Created_Date : "+Name[8]+",Expiry_Date : "+Name[9]+",Password : "+Name[10]+",Purpose : ProfileDetails").encode())


        if str(Data_Final[3]) == "UpdateProfile":

            UpdateDevice = "UPDATE Devices SET Mobile_Number = '"+str(Data_Final["Mobile_Number"])+"', Password = '"+str(Data_Final["Password"])+"' WHERE Email = '"+str(Data_Final["Email"])+"'"
            mycursor.execute(UpdateDevice)
            mydb.commit()

            UpdateSignup = "UPDATE Signup SET Number = '"+str(Data_Final["Mobile_Number"])+"', Password = '"+str(Data_Final["Password"])+"' WHERE Email = '"+str(Data_Final["Email"])+"'"
            mycursor.execute(UpdateSignup)
            mydb.commit()

            connection.sendall(("Status : Done,Purpose : UpdateProfile").encode())


    connection.close()

while True:
    Client, address = ServerSocket.accept()
    start_new_thread(threaded_client, (Client, ))
    ThreadCount += 1
ServerSocket.close()