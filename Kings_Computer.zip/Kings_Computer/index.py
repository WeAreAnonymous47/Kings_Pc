#!/usr/bin/python3
from PyQt5.QtWidgets import QDialog, QApplication, QMainWindow, QVBoxLayout
import sys
import os
import datetime
from Main import *
import socket
import subprocess
import urllib
import urllib.request
from zipfile import ZipFile
import mysql.connector
import requests


Date = datetime.date.today()
Time = datetime.datetime.now().time()

ip = requests.get('https://api.ipify.org').text

print (ip)

class LoginPage(QDialog):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)


        self.TopPanel()
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.TopPanel)
        self.timer.start(1000)


        #Place Holders
        self.ui.ContactUsFullNameInput.setPlaceholderText("Enter your Full Name")
        self.ui.ContactUsEmailInput.setPlaceholderText("Enter your Email ID")
        self.ui.ContactUsMessageBox.setPlaceholderText("Enter your Message")
        self.ui.Server_IP_Input.setPlaceholderText("Enter IP Address")

        #Hide Frames
        self.ui.WifiDetailFrame.hide()
        self.ui.WifiFrame.hide()
        self.ui.UpdateFrame.hide()
        self.ui.SettingFrame.hide()
        self.ui.Contact_Us_Frame.hide()
        self.ui.DisplayFrame.hide()


        #Hide Error Messages
        self.ui.VersionStatusText.hide()
        self.ui.Update_ProcessBar.hide()
        self.ui.Update_Available_Text.hide()
        self.ui.ContactUsEnterValidFullNameError.hide()
        self.ui.ContactUsEnterValidEmailError.hide()
        self.ui.ContactUsMessageError.hide()
        self.ui.Done_Not_Message.hide()


        #Buttons
        self.ui.Wifi_Button.clicked.connect(lambda : self.WifiFrameShow("Open"))
        self.ui.WifiButtonSetting.clicked.connect(lambda : self.WifiFrameShow("Open"))
        self.ui.UpdateButton.clicked.connect(lambda : self.UpdateOpener("Open"))
        self.ui.CloseUpdateButton.clicked.connect(lambda : self.UpdateOpener("Close"))
        self.ui.Check_UpdateButton.clicked.connect(lambda : self.CheckUpdate())
        self.ui.SettingsButton.clicked.connect(lambda : self.SettingOpener("Open"))
        self.ui.SettingCloseButton.clicked.connect(lambda : self.SettingOpener("Close"))
        self.ui.ContactButtonSetting.clicked.connect(lambda : self.ContactOpener("Open"))
        self.ui.ContactUS_Close_Button.clicked.connect(lambda : self.ContactOpener("Close"))
        self.ui.Contact_US_Submit_Button.clicked.connect(lambda : self.ContactOpener("Submit"))
        self.ui.DisplayButtonSetting.clicked.connect(lambda : self.DisplayFrameShow("Open"))
        self.ui.DisplayCloseButton.clicked.connect(lambda : self.DisplayFrameShow("Close"))
        self.ui.WifiCloseButton.clicked.connect(lambda : self.WifiFrameShow("SettingsClose"))
        self.ui.LogoutButton.clicked.connect(lambda : self.Logout(str(ip), str(ip)))
        self.ui.ConnectButton.clicked.connect(lambda : self.ConnectDevice())

        self.ui.TV_1.toggled.connect(self.TV_1)
        self.ui.TV_2.toggled.connect(self.TV_2)
        self.ui.TV_3.toggled.connect(self.TV_3)
        self.ui.TV_4.toggled.connect(self.TV_4)
        self.show()



    def DisplayFrameShow(self, Purpose):
        if Purpose == "Open":
            self.ui.SettingFrame.hide()
            self.ui.DisplayFrame.show()
        if Purpose == "Close":
            self.ui.SettingFrame.show()
            self.ui.DisplayFrame.hide()

    
    def TV_1(self):

        if self.ui.TV_1.isChecked():
            #print("9")
            self.ui.Submit_Display.clicked.connect(lambda : self.Display_Submit("9"))

    
    def TV_2(self):

        if self.ui.TV_2.isChecked():
            #print("16")
            self.ui.Submit_Display.clicked.connect(lambda : self.Display_Submit("16"))


    def TV_3(self):

        if self.ui.TV_3.isChecked():
            #print("85")
            self.ui.Submit_Display.clicked.connect(lambda : self.Display_Submit("85"))


    def TV_4(self):

        if self.ui.TV_4.isChecked():
            #print("82")
            self.ui.Submit_Display.clicked.connect(lambda : self.Display_Submit("82"))


    def Display_Submit(self, value):
        with open('/boot/config.txt', 'r') as file:
          filedata = file.read()

        filedata = filedata.replace('#hdmi_group=1', 'hdmi_group=1')

        hdmi_mode = filedata.replace('#hdmi_mode=1', 'hdmi_mode='+str(value))

        with open('/boot/config.txt', 'w') as file:
          file.write(filedata)
         
        with open('/boot/config.txt', 'w') as file:
          file.write(hdmi_mode)

        os.system("sudo reboot")
        

    def ContactOpener(self, Purpose):
        Name = self.ui.ContactUsFullNameInput.text()
        Email = self.ui.ContactUsEmailInput.text()
        Message = self.ui.ContactUsMessageBox.toPlainText()

        if Purpose == "Open":
            self.ui.SettingFrame.hide()
            self.ui.Contact_Us_Frame.show()
        if Purpose == "Close":
            self.ui.SettingFrame.show()
            self.ui.Contact_Us_Frame.hide()
        if Purpose == "Submit":
            Name = self.ui.ContactUsFullNameInput.text()
            Email = self.ui.ContactUsEmailInput.text()
            Message = self.ui.ContactUsMessageBox.toPlainText()

            #mydb = mysql.connector.connect(
            #  host="184.168.114.22",
            #  user="Fuck_Off",
            #  password="Anonymous@01",
            #  database="Kings_Computer",
            #  auth_plugin='mysql_native_password'
            #)

            #mycursor = mydb.cursor()

            Date_Time = str(Date.strftime("%d-%m-%Y"))+" "+str(Time.strftime("%I:%M %P"))

            #Contact_US = "INSERT INTO ContactUS (Name, Email, Number, Message, Date_Time) VALUES (%s, %s, %s, %s, %s)"
            #Contact_US_Value = (str(Name), str(Email), "None", str(Message), str(Date_Time))

            #mycursor.execute(Contact_US, Contact_US_Value)
            
            if str(Name) != "" and str(Email) != "" and str(Message) != "":
            #    mydb.commit()
                self.ui.Done_Not_Message.show()
            else:
                self.ui.Done_Not_Message.show()
                self.ui.Done_Not_Message.setText("Something is Wrong")
                self.ui.Done_Not_Message.setStyleSheet("color: red;")


    def WifiFrameShow(self, Purpose):
        if Purpose == "Open":
            self.ui.ProfilePanelFrame.hide()
            self.ui.WifiFrame.show()
            self.ui.SettingFrame.hide()
        if Purpose == "Close":
            self.ui.WifiFrame.hide()
        if Purpose == "SettingsOpen":
            self.ui.WifiFrame.show()
            self.ui.SettingFrame.hide()
        if Purpose == "SettingsClose":
            self.ui.WifiFrame.hide()
            self.ui.SettingFrame.show()


    def SettingOpener(self, Purpose):
        if Purpose == "Open":
            self.ui.SettingFrame.show()
            self.ui.ProfilePanelFrame.hide()
        if Purpose == "Close":
            self.ui.SettingFrame.hide()
            self.ui.ProfilePanelFrame.show()



    def Logout(self, Email, Password):
        #mydb = mysql.connector.connect(
        #  host="184.168.114.22",
        #  user="Fuck_Off",
        #  password="Anonymous@01",
        #  database="Kings_Computer"
        #)
        
        #mycursor = mydb.cursor()
        
        Date_Time = str(Date.strftime("%d-%m-%Y"))+" "+str(Time.strftime("%I:%M %P"))
        
        #UpdateDevice = "UPDATE Devices SET Running = 'False' WHERE Email = '"+str(Email)+"'"
        #mycursor.execute(UpdateDevice)
        #mydb.commit()

        #Make_Logs = "INSERT INTO Login (Email, Password, Purpose, Date_Time) VALUES (%s, %s, %s, %s)"
        #Values = (str(Email), str(Password), "Logout", str(Date_Time))
        #mycursor.execute(Make_Logs, Values)
    
        #if mydb.commit():
        print("done")
        os.system("sudo poweroff")
        #else:
        #    print("something is wrong")

    def ConnectDevice(self):
        Server_IP = self.ui.Server_IP_Input.text()
        #mydb = mysql.connector.connect(
        #  host="184.168.114.22",
        #  user="Fuck_Off",
        #  password="Anonymous@01",
        #  database="Kings_Computer",
        #  auth_plugin='mysql_native_password'
        #)
        
        #mycursor = mydb.cursor()

        Date_Time = str(Date.strftime("%d-%m-%Y"))+" "+str(Time.strftime("%I:%M %P"))
        
        #mycursor.execute("SELECT IP FROM Devices WHERE Email = '"+str(Email)+"'")

        #myresult = mycursor.fetchone()

        os.system("sudo /VNC-Viewer "+str(Server_IP)+":5901 -fullscreen")
        print(Server_IP+":5901")


    def UpdateOpener(self, Purpose):
        if Purpose == "Open":
            self.ui.ProfilePanelFrame.hide()
            self.ui.UpdateFrame.show()
        if Purpose == "Close":
            self.ui.ProfilePanelFrame.show()
            self.ui.UpdateFrame.hide()


    def CheckUpdate(self):
        VersionFile = open("Version.txt", "r")
        ReadFile = VersionFile.read()
        content_list = ReadFile.split(" ")
        Version = int(content_list[0].replace(".0", ""))+1
        Url = "https://www.techiempire.com/Updates/"+str(Version)+".0"

        print(Url)

        try:
            Get_Status_Code = urllib.request.urlopen(Url).getcode()
        except:
            self.ui.VersionStatusText.show()
            self.ui.VersionStatusText.setStyleSheet("color: red;")
            self.ui.VersionStatusText.setText("System is up to date")
            self.ui.Update_ProcessBar.hide()
        else:
            self.ui.Update_ProcessBar.show()

            Main = urllib.request.urlopen("http://184.168.114.22/Pocket-Computer/Updates/2.0/Main.py")
            with open('/home/vivek/Pycharm/Kings_Computer/Main.py','wb') as output:
                output.write(Main.read())
                for I in range(101):
                    self.ui.Update_ProcessBar.setValue(I)
                    self.ui.VersionStatusText.hide()
                    if I == 100:
                        self.ui.VersionStatusText.show()
                        self.ui.VersionStatusText.setStyleSheet("color: green;")
                        self.ui.VersionStatusText.setText("Wait")


            self.ui.VersionStatusText.hide()
            Version = urllib.request.urlopen("http://184.168.114.22/Pocket-Computer/Updates/2.0/Version.txt")
            with open('/home/vivek/Pycharm/Kings_Computer/Version.txt','wb') as output:
                output.write(Version.read())
                for I in range(101):
                    self.ui.Update_ProcessBar.setValue(I)
                    self.ui.VersionStatusText.hide()
                    if I == 100:
                        self.ui.VersionStatusText.show()
                        self.ui.VersionStatusText.setStyleSheet("color: green;")
                        self.ui.VersionStatusText.setText("Update Successfully Restart your Device")


            self.ui.VersionStatusText.hide()
            index = urllib.request.urlopen("http://184.168.114.22/Pocket-Computer/Updates/2.0/index.py")
            with open('/home/vivek/Pycharm/Kings_Computer/Main.py','wb') as output:
                output.write(index.read())
                for I in range(101):
                    self.ui.Update_ProcessBar.setValue(I)
                    self.ui.VersionStatusText.hide()
                    if I == 100:
                        self.ui.VersionStatusText.show()
                        self.ui.VersionStatusText.setStyleSheet("color: green;")
                        self.ui.VersionStatusText.setText("Update Successfully Restart your Device")


    def TopPanel(self):
        Date = datetime.date.today()
        Time = datetime.datetime.now().time()

        self.ui.Date_Text.setText(Date.strftime("%d-%m-%Y"))
        self.ui.Time_Text.setText(Time.strftime("%I:%M %P"))

        Wifi_Range = subprocess.check_output("sudo nmcli dev wifi list | awk '/\*/{if (NR!=1) {print $8}}'", shell=True)

        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("icons/2_Wifi.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.ui.Wifi_Button.setIcon(icon)

        VersionFile = open("Version.txt", "r")
        ReadFile = VersionFile.read()
        content_list = ReadFile.split(" ")
        Version = int(content_list[0].replace(".0", ""))+1
        Url = "https://www.techiempire.com/Updates/"+str(Version)+".0"

        try:
            Get_Status_Code = urllib.request.urlopen(Url).getcode()
        except:
            pass
        else:
            self.ui.Update_Available_Text.show()



if __name__ == '__main__':
    app = QApplication(sys.argv)
    w = LoginPage()
    w.show()
    sys.exit(app.exec_())