First Rasp on memory and boot it

than creat ssh file menually

than transfer theme folder and pythong setup and work folder to rasp
